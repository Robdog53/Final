import java.util.Date;

import java.util.Random;

/**
 * @author Robert Robinson (Hamilton,Maharrey, Swann) 10590065 PA13 12/06/2016
 */

public class BankAccount {

	private String name;
	private double balance;
	private int acctNum;
	private Date date;
	private static int getaccountsCreated;

	public BankAccount(String name) {
		this.name = name;
		this.balance = 0;
		this.acctNum = generateAcctNum();
		this.date = new Date();
		getaccountsCreated++;

	}

	public double getBalance() {
		return balance;
	}

	public boolean deposit(double money) {
		if (money >= 0) {
			balance += money;
			return true;

		}
		return false;
	}

	public boolean withdraw(double money) {
		if (money >= 0 && money <= balance) {
			balance -= money;
			return true;
		}
		return false;

	}

	public boolean transfer(BankAccount a,double money) {
		if (money > 0 && money <= this.balance) {
			this.balance -= money;
			a.balance += money;
			return true;
		}
		return false;
	}

	public String toString() {
		return name + " [" + acctNum + "]\n" + date.toString() + "\n" + "$" + String.format("%,.2f", balance);
	}

	public boolean equals(BankAccount that) {
		if (this.acctNum == that.acctNum)
			return true;
		else
			return false;
	}
	
	public int getAccountNumber() {
		return acctNum;
	}

	private int generateAcctNum() {
		Random r = new Random();
		String s = r.nextInt(9) + 1 + "";
		for (int i = 1; i <= 8; i++)
			s += r.nextInt(10);
		return Integer.parseInt(s);
	}
	public  static int getAccountsCreated(){
		return getaccountsCreated;
	}

}