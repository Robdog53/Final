import java.util.Scanner;

public class BankTeller {

	private static final String Bank = null;
	private static Bank account = new Bank(1);

	public static void main(String []args){
		char command;
		Scanner input = new Scanner(System.in);
		printMenu();
		
	do {
		System.out.println("Please enter a command or type ? ");
		command = input.nextLine().toLowerCase().charAt(0);
		switch (command) {
		case 'a': account.add();
			break;
		int checkingsORsavings;
		while(checkingsORsavings <1 || checkingsORsavings >2){
			System.out.print("Enter 1 for checkings or 2 for savings:");
			checkingsORsavings = Integer.parseInt(input.nextLine());
		
		}
	}

	private static void printMenu() {
		Scanner input = new Scanner(System.in);
		System.out.println("Bank Teller Options");
		String Options =input.nextLine();
		System.out.println("-----------------------------------");
		System.out.println("a: add an account to the bank ");
		String a =input.nextLine();
		System.out.println("b: remove an account from the bank ");
		String b =input.nextLine();
		System.out.println("c: display the accounts in the bank ");
		String c =input.nextLine();
		System.out.println("d: count the accounts in the bank ");
		String d =input.nextLine();
		System.out.println("e: sort the accounts in the bank ");
		String e =input.nextLine();
		System.out.println("f: update an account in the bank ");
		String f =input.nextLine();
		System.out.println("?: display the menu again ");
		String nocomprenda =input.nextLine();
		System.out.println("q: quit this program ");
		String q =input.nextLine();
		
		
		Account a1;
		if (checkingsORsavings == 1){
			System.out.print("Enter account holder name: ");
			int n =Integer.parseInt(input.nextLine());
			n = new Account();
			
		}else{
			System.out.print("Enter starting check number: " + 100);
			int t = Integer.parseInt(input.nextLine());
			case 'a' = account.add();
			break;
		
			
		if ((account.add(n)) System.out.print("\nAccount added successfuly\n");
		else System.out.print("Account not added. No duplicates please.\n");
		case 'b'= account.remove();
		System.out.print("\nremove  ");
		long acct = Long.parseLong(input.nextLine());
		if (account.remove(account.find(acct))) System.out.print("\nAccount successfully removed.\n");
		else System.out.print("Account not found. Cannot remove.\n");
		break;
		case 'c': account.display();
		System.out.println(account.toString());
		break;
		case 'd': account.getCount();
			System.out.println("\nThere are " + account.getCount() + " accounts in the bank");
			break;
		case 'e': account.sort(Bank);
		
				break;
				case 'f': acccount.update();
				System.out.print("\n The Account is upadted");
				// update account
				break;
				case '?': account.printmenu();
				
				return printmenu();
				break;
				case 'q': account.quit();
				System.out.print("\nGOODBYE");
}
	}
}
