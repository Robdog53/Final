import java.util.Scanner;
public class SavingsAccount extends BankAccount {
	Scanner scan=  new Scanner(System.in);
private static final String String;
private static final String Interest;
private double interestRate; 
 String name;
	
	public SavingsAccount(String name, double rate) {
		super(name);
		if(rate > 0 && rate < 10)
		double interestRate= rate;
		else interestRate= 1;
		// TODO Auto-generated constructor stub
	}
	private double getRate() {
		return interestRate;
	}
	public String toString() {
		return ("Savings Account\n" + super.toString() + "\n" + );
	}
private void addInterest() {
	return;
}
}
