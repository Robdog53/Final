
public class TestBankAccount {
	public static void main(String []args){
		BankAccount b= new BankAccount("t=panda");
		System.out.println(b.toString());
		
	}
}
