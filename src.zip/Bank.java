// Name: Robbie Robinson        (SI, Maharrey) 
// Assignment:  PA13 Bank 
// Description: This class is used to manage BankAccount objects 
// Time spent:  2.5 hours 
// 12/06/2016
public class Bank {
	private BankAccount[] accounts;
	private int count;

	public Bank(int cap) {

		accounts = new BankAccount[cap];

		count = 0;

	}

	private int indexOf(BankAccount a) {
		for (int i = 0; i < accounts.length; i++) {
			if (accounts[i] == a)
				return i;
		}
		return -1;

	}

	public boolean contains(BankAccount a) {
		for (int i = 0; i < accounts.length; i++) {
			if (accounts[i] == a)
				return true;
		}
		return false;

	}

	public boolean add(BankAccount a) {
		if (contains(a))
			return false;
		if (full()) {
			doubleCapacity();
		}
		accounts[count] = a;
		count++;
		return true;

	}

	public boolean remove(BankAccount a) {
		if (!contains(a))
			return false;
		int i = indexOf(a);
		accounts[i] = accounts[count - 1];
		accounts[count - 1] = null;
		count--;
		return true;
	}

	public int getCount() {

		return count;

	}

	public String toString() {

		StringBuilder sb = new StringBuilder();

		sb.append("Bank Accounts\n");

		for (BankAccount a : accounts)

			sb.append(a + "\n    **************    \n");

		return sb.toString();

	}

	public void sort() {
		for (int i = 0; i < count - 1; i++) {
			int min = i;
			for (int j = i; j < count; j++) {
				if (accounts[j].getAccountNumber() < accounts[min].getAccountNumber())
					min = j;
			}
			BankAccount temp = accounts[i];
			accounts[i] = accounts[min];
			accounts[min] = temp;
		}
	}

	private void doubleCapacity() {
		
		BankAccount[] temp = accounts;
		accounts = new BankAccount[temp.length * 2];
		for (int i = 0; i < temp.length; i++) {
			accounts[i] = temp[i];
		}
	}

	private boolean full() {

		return count == accounts.length;

	}

}
