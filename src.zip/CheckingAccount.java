
public class CheckingAccount extends BankAccount {
	private int Check;
	public CheckingAccount(String name, double rate) {
		super(name);
		if(Check > 0)
			double checkNum;
		checkNum= Check;
		else 
			checkNum= 1000;
	}
	public int getcheckNum(){
		return Check;
		
	}
public String toString() {
	return String;
}{
	
}
public void writeCheck();
return checkNum;
}
